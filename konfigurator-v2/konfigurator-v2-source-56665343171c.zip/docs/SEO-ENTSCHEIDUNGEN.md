# SEO-Entscheidungen · 19.09.2026

Ahrefs-Daten im bestehenden Konto geprüft, ohne kostenpflichtige Aktualisierung. Monatliche Volumen sind Tool-Schätzungen für das jeweilige Land, keine Nachfragegarantie. Rohansichten und URLs: qa/final-evidence.json. Nutzerziel: Möbelhersteller/Marken mit CGI- und Konfiguratorbedarf; kein Raumplaner, Autokonfigurator oder Standard-Shopsoftware-Versprechen.

| Sprache | Primärer Zielbegriff | Ergänzende geprüfte Begriffe | Entscheidung |
|---|---|---|---|
| DE | 3d produktkonfigurator, 60, KD 0 | 3d konfigurator 350/KD3, 360 grad produktansicht 40, 3d produktkonfigurator für websites 30, produktkonfigurator erstellen lassen 0–10 | Produktkonfigurator/Umsetzungsabsicht im Titel und H1; 360-Ansicht benennt die Demo. Breites „3D Konfigurator“ enthält viel Automobilabsicht. |
| EN/US | 3d furniture configurator, 250, KD 6 | 360 product viewer 150/KD17, furniture product configurator 50, furniture visualization 150/KD17 | Furniture configurator führt; 360 product viewer als einzelne Bildfunktion, nicht als gleichbedeutende Gesamtleistung. Furniture visualization ist gemischt und wird ergänzend verwendet. |
| FR | configurateur 3d, 150, KD 3 | configurateur produit 30/KD0 | Herstellerfokus über „marques de mobilier“ und „configurateur produit“. Die spezifischen Möbelvarianten waren in Ahrefs nicht indexiert, nicht als validiertes Zusatzvolumen ausgegeben. |
| IT | configuratore 3d, 150, KD 0 | configuratore prodotto 100/KD0, configuratore per arredamento 10 | „marchi di arredamento“ grenzt Hersteller ab. Nicht die ERP-/Angebotssoftware-Funktionen anderer Konfiguratoren versprechen. |

Keine verlässlichen Ahrefs-Werte für fabric configurator, configurateur 3d mobilier, configurateur de mobilier, visualisation de matières, vue produit à 360, configuratore 3d mobili, tessuti e finiture, visualizzazione prodotto 360. Diese Begriffe werden nicht mit erfundenen Zahlen begründet. Materialnamen, Prozessschritte und Leistungsdetails sind sachliche Zwischenüberschriften, keine Behauptung eigenständiger Suchnachfrage.

Suchabsicht zusätzlich gegen Anbieterergebnisse abgeglichen: Colijn/ione360, 3Dvue, i-furniture, Tesy, Station. Keine erneute Grundsatzrecherche. Finale Slugs vor Erstveröffentlichung in Webflow/Weglot gesetzt:
- DE /3d-visualisierung/3d-konfigurator
- EN /en/3d-visualization/3d-furniture-configurator
- FR /fr/visualisation-en-3d/configurateur-3d-mobilier
- IT /it/visualizzazione-3d/configuratore-3d-arredamento

Bestehende Zielseiten-Sprachpfade aus tatsächlichen hreflang-Links übernommen (content/link-map.json); Möbel zusätzlich DE moebel / EN furniture / FR meuble / IT mobili. Weglots Linkumschreibung, Canonical und hreflang wurden beim temporären Live-Test in vier Sprachen geprüft; 15 HTML-Absätze danach direkt in Weglot korrigiert. Die Seite ist anschließend wieder Draft/404. Details: LIVE-SEO-TEST-2026-09-19.md. Gegenlinks und Abgrenzung zum Glossar: INTERNAL-LINKS.md und content/launch-links.json.

Conversion: vorhandene blaue Buttons und Layoutmuster, konkretes Verb/Ziel im CTA, direkter Sprung zum Konfigurator, Anfrage mit übernommener Auswahl. Keine behauptete Conversion-Steigerung ohne Messung. Keine neuen globalen Layouts, Farben oder Testimonials.


## Premium Home & Living – Erweiterung des Zielmarktes
Die Hauptseite bündelt den Bedarf von Möbel- und Home-&-Living-Marken mit hohem Anspruch an Materialwirkung und Bildqualität. „Sessel“ bleibt bei der tatsächlichen Demo und ihrer Bildbeschreibung; die Leistungsüberschrift und Einleitung sind produktübergreifend. Die bestehenden kommerziellen Hauptkeywords und endgültigen URLs bleiben erhalten. Neue H1 DE: „3D Produktkonfigurator für Möbel und Home & Living“. Die anderen Sprachfassungen sind eigenständig passend formuliert und lokal vorbereitet.

Suchvolumen ist kein Ausschlusskriterium. Eine geringe Zahl klarer Herstelleranfragen kann wirtschaftlich relevanter sein als eine große Zahl privater Planungsanfragen. Bewertet werden Auftraggeber, Beschaffungsabsicht, Projektumfang, Passung zur hochwertigen CGI-Produktion und belegbare Leistung. Es gibt weiterhin keine erhobenen Ahrefs-Zahlen für einzelne Sofa-, Küchen- oder Badkonfiguratorbegriffe; insbesondere sind „30 Suchanfragen“ ein Nutzerbeispiel und kein Messwert.

Küchenfronten und Badmöbel erscheinen als mögliche Anwendungsfälle für definierte Materialvarianten. Freie Raumplanung, Module und Preislogik sind ein anderer Umfang. Die Anbieterbeschreibungen von VividWorks (https://www.vividworks.com/de/industries/kuechen-badezimmer) und HomeByMe (https://www.3ds.com/about-homebyme) helfen bei dieser Abgrenzung; sie sind keine Nachfrage- oder Conversion-Belege. Keine zusätzlichen Branchen-Landingpages ohne eigene Inhalte/Leistungsbelege und keine unbestätigten weiteren Demos versprochen.

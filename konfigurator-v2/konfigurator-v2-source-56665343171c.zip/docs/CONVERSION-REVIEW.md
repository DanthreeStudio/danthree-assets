# Konfigurator und Landingpage aus Herstellersicht

Stand 19.09.2026 nach temporärem Live-Test. Bewertung der vorhandenen Bedienung und Texte, kein Nachweis einer Conversion-Steigerung. Die visuellen Produktbelege fehlen noch.

| Frage bzw. Problem | Vorhandene Antwort | Noch nötiger Beleg |
|---|---|---|
| Ein Farbmuster erklärt weder Stoffstruktur noch Verarbeitung | Rotation, drei Detailtypen und Beschreibung von Struktur, Naht, Glanz und Texturmaßstab | Echte Material- und Detailrenderings; physische Referenzen |
| Unterschiedliche Perspektiven erschweren den Variantenvergleich | Winkel bleibt beim Materialwechsel erhalten, feste Kamera- und Lichtvorgaben | Pilot und später sechs tatsächlich korrekt zugeordnete Kombinationen |
| Der Hersteller kennt den nötigen Produktionsumfang nicht | Produktdaten, CAD-Alternative, Pilot, Serienproduktion, Abnahme und Kostenfaktoren erklärt | Projektspezifisches Angebot, keine erfundenen Pauschalpreise |
| Es bleibt unklar, wer Shop und Preislogik liefert | Bildbasierte Darstellung und gesonderter Integrationsumfang ausdrücklich erklärt | Keine automatische Shop-/ERP-Komplettlösung behaupten |
| Interessenten wollen schnell zur Demo und danach zur Anfrage | Bestehender blauer Hero-CTA auf #Portfolio; Auswahlübergabe in Formular; eindeutiger Abschluss-CTA | Nutzungsdaten nach tatsächlichem Launch |
| Mobile Bildmengen werden zu groß | Zuerst Poster, 12 mobile Vorladepositionen, übrige Frames bei Interaktion; nur aktive Kombination; kleine Webbilder und Zoom auf Nachfrage | Tatsächliche Transfermenge und Ladezeit mit 48 echten Pilotbildern auf Geräten |
| Referenzen könnten dem neuen Konfigurator zugerechnet werden | CGI-Bezug ausdrücklich erklärt; Originalkundenstimmen unverändert eingesetzt | Live nach Korrektur: acht Originaltexte wortgleich mit Möbel-Seite |

## Ergebnis

Der Aufbau behandelt die relevanten Kauf- und Produktionsfragen. Ein einzelnes Produkt reicht als verständliches Arbeitsbeispiel; seine Qualität muss durch die tatsächlichen Renderings belegt werden. Der jetzige Platzhalterstand ist keine starke Verkaufsdemo und wird deshalb nach dem Sprachtest wieder unveröffentlicht gehalten.

Keine weitere gestalterische Abweichung eingeführt. Die bestehenden blauen CTAs und Textblöcke bleiben. Für die endgültige Hero-Wirkung ist ein ruhigerer Bildausschnitt entscheidend: Das derzeitige Drahtgittermotiv ist hinter der weißen Schrift unruhig. Der englische Renderbrief fordert deshalb einen nutzbaren Hero-Zuschnitt aus einem der sechs Interior-Motive, mit ruhiger dunkler Textzone. Kein zusätzlicher Renderjob und kein neues Buttondesign.

AR und Downloads bleiben bis zu geprüften Modelldateien deaktiviert. Keine unbelegten Aussagen zu Conversion-Zuwachs, fehlerfreier Farbwiedergabe, vollständiger Shop-Anbindung oder mobilem Geschwindigkeitsgewinn.


## Ergänzender Praxisvergleich und Verbesserung
Am 19.09.2026 wurden zusätzlich [CGIFurniture](https://configurator.cgifurniture.com/products/bernhardt_design/becca), [Prostoria](https://www.prostoria.com/for-professionals/configurator/) und die [Molteni-Konfiguratorbeschreibung](https://shop.molteni.it/pages/3d-configurator) betrachtet. Bei CGIFurniture wurde die Becca-Demo tatsächlich bedient: Bark → Pebble aktualisierte die markierte Stoffauswahl, die Zusammenfassung und die URL. Prostoria/Molteni wurden anhand ihrer öffentlich beschriebenen Funktionen verglichen; keine vollständige praktische Funktionsprüfung behauptet.

Relevanter gemeinsamer Ansatz: Produkt und aktuelle Auswahl sichtbar halten, Materialvergleich ermöglichen und Auswahl in den nächsten Schritt mitnehmen. Zusätzliche Preise, Warenkorb, Maße und AR wären hier ohne echte Produktdaten kein Qualitätsgewinn. Vorhandene Winkelhaltung, Materialauswahl und Anfrageübernahme passen zum Herstellerziel. Aussagen über höhere Conversion der Vergleichsseiten werden nicht gemacht.

Konkrete Korrektur: Die seitenspezifische Anfragebrücke ersetzte bislang bei wiederholtem Übernehmen nicht die alte Auswahl, sondern stellte weitere Auswahlen vor den Nachrichtentext. Jetzt wird die zuvor automatisch eingefügte Auswahl aktualisiert, eigener Nachrichtentext bleibt erhalten und derselbe Auswahlklick erzeugt keine Duplikate. Ein manuell veränderter alter Auswahltext wird nicht stillschweigend gelöscht. Lokaler Browsertest mit tatsächlichem Einbettungscode: F01/G01 → F03/G02 → F03/G02, freie Notiz erhalten, eine aktuelle Auswahl. Code in Webflow gespeichert und durch erneutes Öffnen bestätigt; Status weiterhin Draft. Formular wurde nicht versendet. Kein Eingriff in globale Formular-Komponente.


## Umgesetzte Ergänzung: Details, Vergleich und Weitergabe
Die Auswahl erlaubt einen direkten Wechsel zum passenden Stoff- oder Gestelldetail, sobald ein geprüftes Bild verfügbar ist. Eine Kombination kann gemerkt und mit der aktuellen Auswahl abwechselnd betrachtet werden; Perspektive und Ansicht bleiben erhalten. Fehlende Varianten lassen sich nicht als verfügbare Bilder vergleichen. Der Vergleich lädt nur das benötigte Bild und startet keine zusätzliche vollständige Drehsequenz.

Ein Auswahl-Link enthält Stoff, Gestell, Winkel und Ansicht, wird beim Öffnen validiert und führt auf die passende Sprachfassung der Landingpage. Die Webflow-Einbettung reicht den Zustand an den Viewer weiter. Die Landingpage ist weiterhin Draft, deshalb sind solche Links noch keine öffentlichen Endnutzerlinks. Kein Konto, keine zusätzliche Datenspeicherung und kein zusätzlicher AWS-Dienst notwendig.

Lokaler Bediennachweis mit klar gekennzeichneten synthetischen Testdateien: F01/G01 merken, auf F03 wechseln, Vergleich zurück und vor; Winkel 45° erhalten, Auswahlfelder und Anfragezusammenfassung korrekt. Stoffdetail aufgerufen, Auswahl-Link erzeugt; französischer Aufruf mit gespeicherter Auswahl korrekt wiederhergestellt. 7 Kerntests bestanden. Neue Buttons mindestens 44 px hoch in vier Sprachen bei 320/390 px. Produktionsbilder und reale Gerätetests bleiben ausstehend.

Die Funktionen nutzen den unveränderten Umfang von 305 Renderings. Der englische Renderbrief bleibt gültig. Das Code-/Schriftbundle wächst um 5930 Bytes auf 201283 Bytes; das ist keine Aussage zur realen Netzwerkübertragung pro Besuch. Das mobile Konzept bleibt: kleines Einstiegsbild, 12 verteilte Vorladepositionen, restliche Frames bei Interaktion, hohe Auflösung nur für Zoom/Details. Keine zusätzlichen Bildserien für die neuen Funktionen.

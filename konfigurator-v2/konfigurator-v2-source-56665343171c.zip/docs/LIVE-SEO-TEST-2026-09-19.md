# Temporärer Live-Test und Rückkehr zum Draft

Der Nutzer hat am 19.09.2026 eine vorübergehende Veröffentlichung für Weglot-Prüfung und anschließende Rücknahme ausdrücklich erlaubt.

## Ausgeführt

- Veröffentlichung auf danthree-final.webflow.io und www.danthree.studio. Webflow bietet in diesem Projekt die Veröffentlichung auf Domain-Ebene; kein Unpublish der gesamten Domain ausgeführt.
- Alle vier tatsächlich erreichbaren Sprachfassungen geprüft: finale Slugs, eine H1, vorbereitete Meta Titles und Descriptions, selbstreferenzierende Canonicals, vier richtige hreflang-URLs, sprachpassender eingebetteter Konfigurator und Schema-Sprachen de-DE/en-US/fr-FR/it-IT. Gleiche acht Graph-Knotentypen wie vorbereitet; keine neue Schemaform.
- Fünf verlinkte Absatztypen je Fremdsprache als tatsächliche Weglot-HTML-Einträge korrigiert: Einleitung, erster Prozessschritt, Interior, Kompetenz und Material. Insgesamt 15 direkte Bearbeitungen mit erhaltenen wg-Linkmarkierungen. Vorherige reine Textimporte deckten diese HTML-Einträge nicht ab. Keine weiteren Dateiimporte in diesem Arbeitsschritt.
- Weglot erzeugt bei den echten Absätzen eigene Schlüssel mit `<a wg-1="">` und zum Teil `<br wg-2="">`. Die frühere Datei weglot-seo-rich.csv mit echten href-Attributen ist nicht als erfolgreicher Import zu behandeln.
- Neuer Live-Befund: Nach dem vorherigen Entkoppeln lieferte der lokale Kundenstimmenblock Lorem-ipsum-Platzhalter. Die originale Kundenstimmen-Komponente auf der Möbelseite blieb korrekt. Nur den lokalen defekten Abschnitt ae026633-a190-9658-b3d6-e1d08233eeab entfernt und eine unveränderte Instanz von „Clients Review“ aus der Komponentenbibliothek eingesetzt. Neue Instanz a16066b6-2e82-8cc7-ba62-0a39bfb00680. Originalposition zwischen Vorteilen und Ablauf hergestellt. Keine globale Komponentenbearbeitung.
- Nach Korrektur auf allen vier Live-Seiten acht echte Kundenstimmen, kein Lorem ipsum; deutsche Texte wortgleich mit der Möbelseite. Keine Warnung „will modify 49 instances“ ausgelöst. Die Komponentenbibliothek nennt 49 Instanzen für Contact; diese Zahl ist keine ausgelöste Änderungswarnung.
- Seite über „Save as draft“ zurückgesetzt, Draft in Seitenliste bestätigt und Draft-Status auf dieselben beiden Domains veröffentlicht. Alle vier öffentlichen Konfigurator-URLs zeigen anschließend die jeweilige 404-Seite.
- Damit keine Bestandslinks auf die unveröffentlichte Seite führen, weisen die zwei kontextuellen Links während der Draft-Phase auf /glossar/3d-produktkonfigurator. Beim endgültigen Launch beide wieder auf /3d-visualisierung/3d-konfigurator setzen und gemeinsam veröffentlichen. Weglot übernimmt die Sprachziele; beim Launch kurz prüfen.

## Belege und Grenzen

qa/live-seo-evidence-2026-09-19.json enthält Live-Metadaten, Graphen, Text-/Linkausgabe und die direkten Korrekturen. Die vier ersten FR-Korrekturen wurden vor Beginn des maschinellen Bearbeitungsprotokolls ausgeführt; ihre finale Live-Ausgabe ist in liveDeltas enthalten. Es wurde kein erneuter Schema-Validatorlauf benötigt, weil der Graph nicht verändert wurde.

Die tatsächliche mobile Viewport-Umschaltung dieses Browserlaufs griff nicht: trotz angeforderter 390 px wurden rund 2416 px gemessen. Diese Messung ist ausdrücklich **keine** erfolgreiche mobile Live-Prüfung. Die vorherigen lokalen Layoutprüfungen bei 320 und 390 px in vier Sprachen bleiben separate Belege. Echte Touch-Geräte, Produktbildqualität und Transfermenge bleiben Teil der Pilotabnahme.

Die automatische Freigabeprüfung hielt zunächst den unklar benannten Publish-Menüknopf und später einen zusammengefassten Rücknahmeschritt an. Nach DOM-Nachweis des reinen Menüknopfs bzw. sichtbarer Prüfung von Draft-Status und Zieldomains wurden die Aktionen freigegeben und ausgeführt. Kein offener Approval-Blocker.

## Vorherige Importbenachrichtigungen

14:56: 204 manuell vorbereitete Textpaare. 16:07: 63 ergänzte/korrigierte Textpaare. Die Dateien wurden aus den vorbereiteten Inhalten erstellt; Weglot musste dafür keine unveröffentlichte Webflow-Seite auslesen. Die Importmails sind automatische Weglot-Benachrichtigungen. Live-Zuordnung war erst im hier dokumentierten Test nachweisbar.

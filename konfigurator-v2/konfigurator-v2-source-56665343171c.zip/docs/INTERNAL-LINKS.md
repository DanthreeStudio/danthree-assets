# Interne Verlinkung und Suchabsicht · 19.09.2026

## Gespeicherter Stand
Die fünf ausgehenden Kontextlinks sind im Webflow-Entwurf enthalten und wurden während der temporären Veröffentlichung in allen vier Sprachfassungen geprüft. Die Landingpage ist wieder unveröffentlicht. Zwei vorhandene eingehende Links auf Möbel und Produkt führen derzeit auf den funktionierenden Glossarartikel. Sie dürfen erst beim tatsächlichen Launch auf die neue Leistungsseite zeigen.

| Von der Landingpage | Ankertext DE | Kontext |
|---|---|---|
| Produktvisualisierung | fotorealistische CGI-Renderings | Einleitung, Bildproduktion |
| Modellierung | bauen wir das Modell neu | Prozess, fehlende CAD-Daten |
| Oberflächen digitalisieren | Digitalisierung von Oberflächen | Materialabgleich |
| Möbelvisualisierung | Möbelvisualisierung | Kompetenz und Varianten |
| Interior | Interior | Dieselbe Auswahl im Raummotiv |

## Zum Launch vorbereitet
| Quellseite | Ankertext DE | Stelle |
|---|---|---|
| Möbelvisualisierung | 3D Möbel Konfigurator | vorhandener Konfigurator-Absatz, bestehendes Linkziel ersetzen |
| Produktvisualisierung | 3D-Konfigurator | vorhandene Textstelle, bestehendes Linkziel ersetzen |
| Glossar Produktkonfigurator | 3D Möbelkonfigurator mit Stoff- und Gestellauswahl | nach Vergleich bildbasiert/Echtzeit, neuer kurzer Praxisverweis |
| Oberflächen digitalisieren | Möbelkonfigurator mit Materialauswahl | nach „Flexibilität“, praktisches Ergebnis der Materialarbeit |

Alle 16 eingehenden Sprachvarianten inklusive genauer URL, Anker und gegebenenfalls vollständigem HTML-Satz stehen in `content/launch-links.json`; dazu die 20 ausgehenden Sprachlinks. Die zwei neuen Absätze und übersetzten eingehenden Anker sind vorbereitet, noch nicht im CMS/Webflow/Weglot gespeichert. Keine globalen Navigationen oder Komponenten werden dafür verändert. Nicht jede Seite braucht einen Rücklink; Kontext geht vor Menge.

## Klare Rollen der beiden Konfigurator-Seiten
Glossar: informieren – Definition, Technikvergleich und Grundlagen. Neue Landingpage: beauftragen – Möbelhersteller, sichtbare Materialwirkung, konkreter Produktionsablauf, Demo und Projektanfrage. Die Seiten behalten eigene Canonicals. Kein Redirect, keine Zusammenlegung, kein identischer kommerzieller Seitentitel.

Der Glossarartikel enthält außerdem eine eng auf Assetlieferung begrenzte Leistungsbeschreibung („Engine, Shop-Anbindung und Hosting bringt dein Entwicklungsteam …“). Bei Aktivierung des Demo-Verweises muss dieser Absatz auf **Echtzeit-/Shop-Projekte** eingegrenzt werden; das neue bildbasierte Arbeitsbeispiel ist separat zu erläutern. Noch nicht geändert. Die pauschale Definition als ausschließlich Echtzeit-Anwendung passt ebenfalls nicht zum späteren Pre-Rendered-Abschnitt. Dies ist eine konkrete redaktionelle Restaufgabe am bestehenden Artikel, keine durch Verlinkung erledigte Korrektur.

## Aktivierung
1. Reale Pilotbilder abnehmen und vier Zielseiten veröffentlichen; Erreichbarkeit prüfen.
2. Zwei bestehende Linkziele ersetzen, zwei vorbereitete seitenspezifische Kontextabsätze einfügen.
3. Weglot-Übersetzungen der geänderten HTML-Blöcke aktualisieren; sprachgleiche Ziele und Anker prüfen.
4. Nach Launch Search Console: Indexierung und Suchanfragen nach Sprache beobachten. Aktuell keine neue Search-Console-Messung oder Rankingverbesserung behauptet.

[Google empfiehlt beschreibende, kontextbezogene und technisch crawlbare Links](https://developers.google.com/search/docs/crawling-indexing/links-crawlable). Mehr interne Links allein garantieren keine bessere Position.

> Nachtrag 19.09.2026: Der erste echte Live-Test zeigte im entkoppelten lokalen Kundenstimmenblock Platzhalter. Das war in der vorherigen Designerprüfung nicht sichtbar. Der lokale Block wurde durch eine unveränderte Clients-Review-Komponenteninstanz ersetzt; anschließend wurden alle acht deutschen Originaltexte live wortgleich mit der Möbelseite bestätigt. Keine globale Kundenstimme wurde geändert. Siehe LIVE-SEO-TEST-2026-09-19.md.

# Komponentenprüfung · 19.09.2026

Anlass: ausdrückliche Nutzeranweisung, keine globalen Komponenten ohne Freigabe zu bearbeiten.

Designer-Seite Konfigurator: 6aae6b848e67a384814e124c.
Gegenprüfung im aktuellen Designer, nicht nur auf der veröffentlichten Website: Badezimmer-Seite 65856ffe8981a4215c99bf9b. Ausgangssicherung: danthree-final.webflow.zip von vor der Bearbeitung.

| Block | Aktueller Status | Änderung |
|---|---|---|
| Navigation | Global verbunden | Keine |
| Hero, Einleitung, Viewer, Vorteile, Ablauf, Editorial, Kompetenz, FAQ | Seitenspezifisch | Konfigurator-Inhalt |
| Logowand-Rahmen und Überschrift | Instanz lokal gelöst | CGI-Referenzen von Danthree Studio; zusätzlicher CTA entfernt |
| Verschachtelte Logosammlung | Weiterhin global verbunden | Unverändert |
| Kundenstimmen-Rahmen und Überschrift | Instanz lokal gelöst | Originalüberschrift „Was unsere Kunden sagen:“ wiederhergestellt; CMS-Einträge selbst nicht bearbeitet |
| Kontakt inklusive Formular | Instanz lokal gelöst | Überschriften und Einleitung geändert; Formularelemente nicht global bearbeitet |
| CTA nach Viewer | Zunächst nur Instanz-Textproperty geändert; anschließend ebenfalls lokal gelöst | Konfigurator-Projekt besprechen; Ziel #Kontakt neu explizit gesetzt und geprüft |
| Magazinlogos | Global verbunden | Unverändert |
| Footer | Global verbunden | Unverändert |

Gegenprüfung: Die Badezimmer-Seite zeigt im Designer weiterhin „High-End Produkt Marketing in 3D für herausragende Marken“, „Was unsere Kunden sagen:“ und „Kontakt aufnehmen“. Der Kontakttext enthält weiterhin den ursprünglichen Willkommen-Text und die Anschrift. Keine der neuen Konfigurator-Beschriftungen findet sich dort. Die Original-CTA-Texte lauten weiterhin „Case Studies entdecken“, „Projekt anfragen“ und „Projekt besprechen“.

Keine Warnung „will modify X instances“ wurde bei den durchgeführten Bearbeitungsschritten beobachtet. Der Button „Edit component“ war sichtbar, wurde nicht zur Bearbeitung der globalen Originale verwendet. Gelöst wurde mit „Unlink instance“ bzw. Cmd+Shift+A. Keine globale Rücknahme erforderlich nach dieser Gegenprüfung.

Die zwischenzeitlichen seitenbezogenen Design-Overrides wurden vollständig entfernt. Hero, Textblöcke und CTAs verwenden vorhandene Webflow-Klassen. „new cta button“ wurde auch dem lokalen Hero-Button zugewiesen; die Klasse selbst wurde nicht bearbeitet. Zwei leere, überlagernde Hero-Embeds entfernt.

Zusätzlicher vollständiger Exportvergleich: Alle 71 gemeinsamen HTML-Seiten des Vorher-/Nachher-Exports verglichen. Nach Normalisierung des Exportzeitstempels und automatisch berechneter Bild-sizes sind nur die beiden beabsichtigten Rücklinks auf Möbel und Produkt verändert. Dort ursprüngliche Textauszeichnung vollständig wiederhergestellt; beim Produktabsatz ist ein geschütztes Leerzeichen nun ein normales Leerzeichen. CSS-Differenzen betreffen umgeschriebene bzw. entfernte Grid-IDs der Konfigurator-Seite. Kein beobachteter globaler Inhaltswechsel. Beleg: qa/final-global-diff.json.

Letzter Stand nach ZIP-Sicherung: nur der lokale Hinweis „Die gezeigten Kundenreferenzen …“ wurde zu „Die gezeigten Referenzen …“ vereinheitlicht, damit die bereits importierten Übersetzungen exakt greifen.

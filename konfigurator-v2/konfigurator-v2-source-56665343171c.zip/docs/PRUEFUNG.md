> Neuester Prüfstand: Temporärer Live-Test der vier Weglot-URLs und anschließende Rückkehr zum Draft erfolgreich; 15 Absatzübersetzungen und lokaler Kundenstimmenblock korrigiert. Details und Einschränkung zur unwirksamen mobilen Live-Viewport-Umschaltung in LIVE-SEO-TEST-2026-09-19.md.

# Prüfung und belastbare Grenzen

Rohbeleg: qa/final-evidence.json, einmal gespeichert; spätere Änderungen in Diffs. 19.09.2026.

- Schema.org: 0 Fehler, 0 Warnungen.
- Google Rich Results: 5 gültige Elemente. Drei Presseartikel aus der unveränderten Organization enthalten jeweils optionale Hinweise (Bild, Datum/Uhrzeit bzw. Zeitzone, Autor-URL/Autor). Keine Änderung dieser global übernommenen Knoten. Ergebnis: https://search.google.com/test/rich-results/result?id=gtoiXfa3vG9Ctuv86QL4-w
- Webflow: eine H1; native mobile Vorschau, direkter Hero-Anker zur eingebundenen Demo; tatsächliche CMS-Kundenstimmen im Designer-Vorschaumodus erhalten. Vorher-/Nachher-Exportvergleich über 71 gemeinsame Seiten: nur zwei gewollte Rücklinks außerhalb der neuen Landingpage. Originale Bold-Klassen wiederhergestellt.
- Native DE-Vorschau 393px: Dokumentbreite entspricht Bildschirmbreite. Ein Kontakt-H2-Container liegt durch das bestehende Kontaktlayout teilweise links außerhalb seiner Elternbox; Text bleibt lesbar, kein horizontales Scrollen. Lokale Exportprüfung der Texte ergibt keinen Überstand.
- Viewer 320/390px × DE/EN/FR/IT: keine Überstände, Dreh-/Zoom-/Stoff-/Gestell-/Anfrageflächen mindestens 44px. Französische Auswahl F03/G02 über die echte Oberfläche bedient und bestätigt.
- Landingpage-Umbrüche: vier vorbereitete Sprachfassungen im Webflow-Export bei 320/390px, jeweils eine H1, kein horizontaler Text-/CTA-Überstand. Das sind Layouttests vorbereiteter Texte; bestehende globale Sprachsegmente/CMS und tatsächliche Weglot-Segmentierung sind darin nicht geprüft.
- 6 Kernfunktionstests bestanden: 48er Rotation, Ansichtserhalt bei Materialwechsel, eindeutige 305 Bildpfade, veraltete Ladeantworten, Speicherbudget/Deduplizierung, Namensprüfung und mobile Nachladefolge.
- Bildaufbereitung mit 48 rein synthetischen technischen Prüfbildern getestet: 144 Ableitungen, Transparenz erhalten, kein Hochskalieren. Diese Dateien waren nur temporär und wurden nie als Produktbilder gespeichert/veröffentlicht.

Offene Abnahme mit echten Assets: Bildqualität und 48er Sequenz, Materialübereinstimmung, tatsächliche HTTP-Daten pro Besuch, Ladezeit auf mobilem Netz und reale iPhone-/Android-Bedienung. Keine gemessene 20-MB-Annahme, keine Aussage „schneller als 5 Sekunden“ ohne realen Test.

Die lokale Vorschau nutzt das identische lokale Viewer-Bundle, weil die enthaltene CloudFront-WAF die URL mit localhost im parentOrigin-Parameter blockiert. Keine WAF-Regel gelockert. Die Webflow-Vorschau mit eigenem HTTPS-parentOrigin funktionierte; die öffentliche CF-Version ohne localhost-Parameter ist erreichbar.

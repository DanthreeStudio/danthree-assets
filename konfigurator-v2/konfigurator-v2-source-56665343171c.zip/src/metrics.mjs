// Resource Timing measures actual browser transfers, including cache reuse.
// It is not a billing counter: CDN/origin costs and retransmissions need AWS data.
export class VisitMetrics {
  constructor() {
    this.started = performance.now(); this.firstImageMs = null; this.entries = [];
    this.observer = new PerformanceObserver(list => this.entries.push(...list.getEntries()));
    this.observer.observe({type:'resource', buffered:true});
  }
  firstImage() { if (this.firstImageMs===null) this.firstImageMs=Math.round(performance.now()-this.started); }
  snapshot() {
    const resources=this.entries.filter(e=>/^https?:/.test(e.name));
    const navigation=performance.getEntriesByType('navigation')[0];
    const documentTransferBytes=navigation?.transferSize||0;
    const images=resources.filter(e=>e.initiatorType==='img');
    const sum=(items,key)=>items.reduce((n,e)=>n+(e[key]||0),0);
    const opaque=resources.filter(e=>e.transferSize===0&&e.encodedBodySize===0);
    return {elapsedMs:Math.round(performance.now()-this.started),firstImageMs:this.firstImageMs,
      documentTransferBytes,documentEncodedBytes:navigation?.encodedBodySize||0,
      measuredTransferBytes:documentTransferBytes+sum(resources,'transferSize'),imageTransferBytes:sum(images,'transferSize'),
      encodedImageBytes:sum(images,'encodedBodySize'),networkImageRequests:images.filter(e=>e.transferSize>0).length,
      cachedImageRequests:images.filter(e=>e.transferSize===0&&e.encodedBodySize>0).length,
      opaqueResourceCount:opaque.length,measurementComplete:opaque.length===0,
      note:'One document visit. Resource Timing bytes; opaque cross-origin resources require Timing-Allow-Origin. Local blob files do not represent network traffic.'};
  }
}

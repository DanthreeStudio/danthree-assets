// Diagnostic pattern only: explicit test image, never a simulated product or production asset.
export function fixtureURL(s) {
 const index=String(s.index).padStart(3,'0'), a=s.index*7.5*Math.PI/180;
 const x=384+190*Math.sin(a),y=370-190*Math.cos(a);
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="768" height="768" viewBox="0 0 768 768"><rect width="768" height="768" fill="#e7e5e0"/><g fill="none" stroke="#b9b5aa"><path d="M0 384H768M384 0V768"/><circle cx="384" cy="370" r="230"/><circle cx="384" cy="370" r="190"/></g><path d="M384 370L${x} ${y}" stroke="#1e1d1d" stroke-width="2"/><circle cx="${x}" cy="${y}" r="12" fill="#1e1d1d"/><g fill="#1e1d1d" text-anchor="middle" font-family="Arial"><text x="384" y="348" font-size="64">${index}</text><text x="384" y="403" font-size="19">${s.fabric.toUpperCase()} / ${s.frame.toUpperCase()}</text><text x="384" y="444" font-size="16">${s.view} · ${s.detail} · ${s.index*7.5}°</text><text x="384" y="684" font-size="12">TEST PATTERN · NOT A PRODUCT RENDERING</text></g></svg>`;
 return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

export const COUNT = 48;
export const wrap = n => ((Math.round(n) % COUNT) + COUNT) % COUNT;
export const angle = n => wrap(n) * 7.5;
export const keyOf = s => `${s.fabric}/${s.frame}/${s.view}/${s.detail}/${wrap(s.index)}`;
export function assetPath(s) {
  const root = `chair-01/${s.fabric}/${s.frame}`;
  if (s.view === 'interior') return `${root}/interior/main.png`;
  if (s.view === 'details') {
    if (s.detail === 'fabric') return `chair-01/materials/fabric/${s.fabric}/detail.png`;
    if (s.detail === 'frame') return `chair-01/materials/frame/${s.frame}/detail.png`;
    return `${root}/detail/junction.png`;
  }
  return `${root}/spin/${String(wrap(s.index)).padStart(3, '0')}.png`;
}
export function orderAround(index, direction = 1) {
  return Array.from({length: COUNT}, (_, i) => wrap(index + i * direction));
}
export function changeState(state, patch) {
  const next = {...state, ...patch};
  if (!['f01','f02','f03'].includes(next.fabric) || !['g01','g02'].includes(next.frame)) throw Error('Unknown material');
  if (!['spin','details','interior'].includes(next.view) || !['fabric','frame','junction'].includes(next.detail)) throw Error('Unknown view');
  next.index = wrap(next.index); next.zoom = Math.max(1, Math.min(4, Number(next.zoom) || 1));
  return next;
}
// Only the latest intent may commit a decoded image, even if requests finish out of order.
export class LatestRequest {
  epoch = 0;
  invalidate() { this.epoch++; }
  async run(load, commit, fail) {
    const epoch = ++this.epoch;
    try { const value = await load(); if (epoch === this.epoch) { commit(value); return true; } }
    catch (error) { if (epoch === this.epoch) fail(error); }
    return false;
  }
}
export class ImageCache {
  constructor(load, budget = 128 * 1024 * 1024) { this.load = load; this.budget = budget; this.bytes = 0; this.items = new Map(); this.pending = new Map(); this.generation=0; }
  async get(url) {
    if (this.items.has(url)) { const item = this.items.get(url); this.items.delete(url); this.items.set(url,item); return item.image; }
    if (this.pending.has(url)) return this.pending.get(url);
    const generation=this.generation;
    const p = this.load(url).then(image => {
      const bytes = image.naturalWidth * image.naturalHeight * 4;
      if (generation===this.generation && bytes <= this.budget) {
        while (this.bytes + bytes > this.budget && this.items.size) { const k=this.items.keys().next().value; this.bytes -= this.items.get(k).bytes; this.items.delete(k); }
        this.items.set(url,{image,bytes}); this.bytes += bytes;
      }
      return image;
    }).finally(()=>{if(this.pending.get(url)===p)this.pending.delete(url);});
    this.pending.set(url,p); return p;
  }
  clear() { this.generation++; this.items.clear(); this.pending.clear(); this.bytes=0; }
}
export function validatePilotNames(files) {
  if (files.length !== COUNT) throw Error('Exactly 48 files required');
  const map = new Map();
  for (const file of files) {
    const m = /^(\d{3})\.(png|jpe?g|webp|avif)$/i.exec(file.name);
    if (!m || +m[1] >= COUNT || map.has(+m[1])) throw Error('Unique files 000–047 required');
    map.set(+m[1],file);
  }
  return Array.from({length:COUNT}, (_,i)=>map.get(i));
}

export function sourceURL(asset,{mobile=false,high=false}={}) {
  if(!asset?.approved)return null;
  if(high&&asset.zoomURL)return asset.zoomURL;
  return mobile&&asset.mobileURL?asset.mobileURL:asset.url;
}
export function preloadIndices(index,{mobile=false,interacted=false,saveData=false}={}) {
  if(saveData&&!interacted)return [wrap(index)];
  if(mobile&&!interacted)return Array.from({length:12},(_,i)=>wrap(index+i*4));
  return orderAround(index);
}

// Share only validated product choices. No arbitrary URL or executable state is accepted.
export function encodeSelection(s) {
 const valid=changeState(s,{});
 return ['v1',valid.fabric,valid.frame,valid.index,valid.view,valid.detail].join('.');
}
export function decodeSelection(value) {
 const m=/^v1\.(f0[1-3])\.(g0[1-2])\.([0-9]|[1-3][0-9]|4[0-7])\.(spin|details|interior)\.(fabric|frame|junction)$/.exec(value||'');
 return m?{fabric:m[1],frame:m[2],index:Number(m[3]),view:m[4],detail:m[5],zoom:1}:null;
}

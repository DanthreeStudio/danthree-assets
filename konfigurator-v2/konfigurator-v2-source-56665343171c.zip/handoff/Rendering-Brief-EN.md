# Danthree Studio furniture configurator rendering brief

Production handoff · 19 September 2026 · V2

Please produce a 48-image rotation pilot of one armchair combination first. The complete approved scope is 305 still renderings: three fabrics, two frame finishes and six combinations. The pilot is part of this total, not an additional set. Produce the remaining combinations after the pilot has been reviewed in the configurator.

## Production list

| Deliverable | Variants | Images per variant | Total |
|---|---|---:|---:|
| Horizontal 360° rotation | F01/G01, F01/G02, F02/G01, F02/G02, F03/G01, F03/G02 | 48 | 288 |
| Fabric close-up showing weave, seam and upholstery edge | F01, F02, F03 | 1 | 3 |
| Frame close-up showing finish and a construction connection | G01, G02 | 1 | 2 |
| Upholstery-to-frame junction close-up | All six combinations | 1 | 6 |
| Interior view from one fixed camera | All six combinations | 1 | 6 |
| **Total still renderings** | | | **305** |

F01–F03 and G01–G02 are production IDs. They are not final material names. Please keep the same ID assignment throughout production.

## First delivery of 48 pilot images

Choose one combination that exposes difficult material behaviour, fine upholstery detail and frame reflections. Confirm its fabric/frame IDs in the handoff. Deliver only its complete 48-image spin before rendering the other five sequences.

- Use 48 unique horizontal camera positions at 7.5° intervals: 0°, 7.5°, 15° … 352.5°.
- Name frames 000.png through 047.png. Frame 000 is the defined front view. Do not add a duplicate 360° frame.
- State the rotation direction. Keep this direction identical in every sequence.
- Frame 006 is 45° and is the proposed initial view. We will confirm this against the actual chair.
- Keep camera height, focal length, distance, product position, lighting, exposure and framing fixed across all material combinations. Establish camera height and focal length from the actual product; there is no mandatory universal lens.
- Keep the whole chair, feet and shadow inside the frame at every angle, with sufficient margin. Do not automatically recenter or resize individual frames.
- Keep the model at its real dimensions. Preserve UV coordinates, fabric scale, seam placement and geometry across variants.
- Deliver a quick contact sheet as a derivative if useful; it does not require extra render jobs.

The pilot checks rotation continuity, direction changes, material detail at web resolution, zoom, touch interaction and actual transferred bytes. If 48 views show unacceptable angular stepping, discuss that finding before series production. Do not silently increase the frame count, interpolate synthetic views or blend double contours.

**After an approved pilot: 240 further rotation images + 17 detail/interior images = 257 remaining images.**

## Master image requirements

| Image type | Master output | Colour and format |
|---|---|---|
| Rotation | Proposed 4096 × 4096 px, identical canvas for all 288 images | sRGB, lossless PNG preferred; lossless TIFF accepted by arrangement |
| Fabric, frame and junction details | At least 4096 px on the long edge | sRGB, lossless PNG; fixed camera and crop for each detail type |
| Interior | At least 4096 px on the long edge | sRGB, lossless PNG; one approved scene and camera, consistent aspect ratio |

Retain the original render scene and source files in the production pipeline. Do not bake labels, arrows, watermarks, UI or material names into the images.

Use a clean neutral rotation background coordinated with #e7e5e0 and render the contact shadow. Transparent output is optional only after clean edges and shadows have been tested. Avoid clipped highlights, denoising that removes the weave, halos around the silhouette, exposure flicker and changing texture scale.

The web team will derive mobile, desktop, zoom, poster and hero crops from the masters. Current web targets are up to 768 px, 1280 px and 2048 px on the long edge; final compression will be judged using the pilot. You do not need to render these sizes separately.

## Detail shots and interior

**Fabric details — three files.** Show a useful area of weave, a seam and the upholstery edge. Avoid an exaggerated macro scale that misrepresents the material. Frame the shot so the other frame finish does not materially affect visible colour, reflected light or the crop.

**Frame details — two files.** Show the surface finish and a meaningful construction connection. Frame the shot so changing upholstery does not materially affect it.

**Junction details — six files.** Show how upholstery and frame meet. Render each complete combination so contact, reflected colour and indirect light remain correct.

**Interior — six files.** Use one approved architectural setting and one fixed camera. Change only the selected fabric and frame finish, including their correct effects on reflections and indirect light. Maintain product scale and position. Compose with a useful mobile crop in mind. One approved interior image should also support a wide desktop hero crop and a portrait mobile crop. Keep a calm, sufficiently dark central area behind the existing white headline and allow room below it for the blue button; provide a crop preview before the interior series. This reuses an existing render and does not add a render job.

Do not simply composite independent fabric and frame layers without a visual comparison against a complete render. If the shared fabric/frame detail crops cannot meet the reuse conditions, test a better crop first and report the exact additional image count before extending production.

## File delivery

Use lowercase folder names, zero-padded frame numbers and the following structure. Examples below show F01/G01; repeat spin, junction and interior folders for all six combinations.

```text
chair-01/
  f01/g01/spin/000.png ... 047.png
  f01/g01/detail/junction.png
  f01/g01/interior/main.png
  f01/g02/spin/000.png ... 047.png
  f01/g02/detail/junction.png
  f01/g02/interior/main.png
  f02/g01/ ...
  f02/g02/ ...
  f03/g01/ ...
  f03/g02/ ...
  materials/fabric/f01/detail.png
  materials/fabric/f02/detail.png
  materials/fabric/f03/detail.png
  materials/frame/g01/detail.png
  materials/frame/g02/detail.png
```

Deliver the pilot and final series as separate clearly named ZIP packages. Keep the folder tree intact. Do not replace a missing angle with a duplicate image. Include a short delivery note identifying the product, combination, camera direction, image dimensions, colour profile and any known issue.

The accompanying `Render-Jobs-EN.json` contains all 305 unique output paths. Shared details are listed once, even though multiple combinations use them.

## Information to include with the images

- Product/model name and actual width, depth and height, with units.
- Mapping of F01, F02 and F03 to the actual fabric names, colour names and references.
- Mapping of G01 and G02 to the actual frame finish names and references.
- Approved display names in German, US English, French and Italian, where available. Do not invent manufacturer names or material claims; flag missing translations for the content team.
- Material reference images or physical sample references, with real texture scale and relevant colour/finish information.
- Confirmation of permission to use the product, textures and rendered imagery on the Danthree website and in the agreed communications.

Five interface swatches can be derived from approved texture samples or suitable detail crops. Hero and poster images are also derivatives. They do not increase the 305-render count.

## Separate optional model delivery

AR and 3D downloads are not required for the initial image configurator and are not included in the 305 stills. If commissioned separately, start with one correctly scaled GLB and one matching USDZ for the pilot combination. The full optional variant set is six GLB plus six USDZ files, exported from one shared geometry source, with explicit material mapping, dimensions and usage rights. Release follows tests on supported physical iPhone and Android devices.

## Delivery checklist

- [ ] Exactly 48 unique numbered images for each completed spin, with no duplicated end frame.
- [ ] Correct front view, rotation direction and 7.5° spacing.
- [ ] Identical framing, light and exposure across the six combinations.
- [ ] Correct fabric scale, seams, geometry and finish assignment.
- [ ] No clipped feet, shadows, silhouette or reflections.
- [ ] Shared detail crops satisfy the material-independence requirements.
- [ ] All six junction views and all six interior variants match their IDs.
- [ ] sRGB masters and original scene files retained.
- [ ] Names, dimensions, material references and usage permissions supplied.
- [ ] File paths match the accompanying job list.

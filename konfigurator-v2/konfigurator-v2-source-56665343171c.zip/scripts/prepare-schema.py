import json,copy,html
from pathlib import Path
r=Path(__file__).resolve().parents[1]
ds=json.loads((r/'content/landing.json').read_text())
reference=json.loads((r/'content/schema-reference-badezimmer.json').read_text())
base='https://www.danthree.studio'
slugs={'de':'/3d-visualisierung/3d-konfigurator','en-US':'/en/3d-visualization/3d-furniture-configurator','fr':'/fr/visualisation-en-3d/configurateur-3d-mobilier','it':'/it/visualizzazione-3d/configuratore-3d-arredamento'}
labels={'de':['Startseite','3D Visualisierung','3D Produktkonfigurator'], 'en-US':['Home','3D visualization','3D furniture configurator'],'fr':['Accueil','Visualisation 3D','Configurateur 3D'],'it':['Home','Visualizzazione 3D','Configuratore 3D']}
captions={'de':'Drahtgittermodell eines Stuhls mit geflochtener Sitzfläche aus der CGI-Möbelproduktion von Danthree Studio','en-US':'Wireframe model of a chair with a woven seat from Danthree Studio’s CGI furniture production','fr':'Modèle filaire d’une chaise à assise tressée, issu de la production CGI de mobilier de Danthree Studio','it':'Modello wireframe di una sedia con seduta intrecciata dalla produzione CGI di mobili di Danthree Studio'}
image='https://cdn.prod.website-files.com/6321ebecf9b0d7fc57007f7e/6a0eaad913dedc4656bca8db_danthree-studio-3d-furniture-visualization-digital-marketing-desktop-lcp.webp'
for lang,d in ds.items():
 url=base+slugs[lang];old=base+'/3d-visualisierung/badezimmer'
 graph=json.loads(json.dumps(reference,ensure_ascii=False).replace(old,url))
 graph['@graph']=[n for n in graph['@graph'] if n['@type']!='VideoObject']
 nodes={n['@type']:n for n in graph['@graph']};page=nodes['WebPage']
 page.update(url=url,name=d['Title'],headline=d['H1'],description=d['Description'],inLanguage={'de':'de-DE','en-US':'en-US','fr':'fr-FR','it':'it-IT'}[lang])
 for k in ['video','datePublished','dateModified']:page.pop(k,None)
 allowed={'interlübke','Kvadrat','JUNG','Wittmann','Schramm','BORA','Natuzzi Italia','Emma Matratzen','Bretz','LEICHT Küchen','Architectural Digest (AD)','Architonic','AW Architektur & Wohnen','Dezeen','DECO Home','HOME'}
 page['mentions']=[m for m in page.get('mentions',[]) if m.get('name') in allowed]
 bc=nodes['BreadcrumbList']['itemListElement'];home=base+({'de':'','en-US':'/en','fr':'/fr','it':'/it'}[lang]);parent=url.rsplit('/',1)[0]
 for n,name,item in zip(bc,labels[lang],[home,parent,url]):n.update(name=name,item=item)
 nodes['ImageObject'].update(url=image,caption=captions[lang],width=1280,height=720)
 service=nodes['Service'];service.update(name=d['H1'],serviceType=d['H1'],description=d['Description'],url=url)
 service['audience']['audienceType']={'de':['Möbel- und Home-&-Living-Marken','Möbel-, Küchen- und Badhersteller','Marketingverantwortliche'],'en-US':['Furniture and home & living brands','Furniture, kitchen and bathroom manufacturers','Marketing teams'],'fr':['Marques de mobilier et de l’habitat','Fabricants de mobilier, de cuisines et de salles de bains','Équipes marketing'],'it':['Marchi di arredamento e prodotti per la casa','Produttori di mobili, cucine e bagni','Team marketing']}[lang]
 nodes['FAQPage']['mainEntity']=[{'@type':'Question','name':q,'acceptedAnswer':{'@type':'Answer','text':a}} for q,a in d['faq']]
 # Existing Organization, Person and WebSite identity nodes stay verbatim.
 assert nodes['Organization']==next(n for n in reference['@graph'] if n['@type']=='Organization')
 assert nodes['Person']==next(n for n in reference['@graph'] if n['@type']=='Person')
 (r/f'content/schema-{lang}.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2))
(r/'content/urls.json').write_text(json.dumps({lang:base+p for lang,p in slugs.items()},ensure_ascii=False,indent=2))
(r/'qa/schema.html').write_text('<meta charset="utf-8"><pre id="schema">'+html.escape('<script type="application/ld+json">\n'+(r/'content/schema-de.json').read_text()+'\n</script>')+'</pre>')
print('4 schema files: existing graph and identity references retained; obsolete video and publication date removed.')

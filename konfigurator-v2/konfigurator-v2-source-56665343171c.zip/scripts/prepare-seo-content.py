import json,html,re
from pathlib import Path
r=Path(__file__).resolve().parents[1];p=r/'content/landing.json';D=json.loads(p.read_text())
D['en-US']['Description']='3D furniture configurators for brands: CGI production, upholstery and frame variants, and 360 product views for your website. Discuss your project with Danthree.'
D['fr']['Description']='Fais réaliser un configurateur 3D pour ta marque de mobilier : rendus CGI, tissus, finitions et vues à 360° pour ton site. Parlons de ton projet.'
D['it']['Description']='Configuratore 3D per il tuo marchio di arredamento: rendering CGI, tessuti, finiture e viste a 360° per il sito. Parliamo del tuo progetto.'
anchors={
'de':['fotorealistische CGI-Renderings','bauen wir das Modell neu','Interior','Möbelvisualisierung','Digitalisierung von Oberflächen'],
'en-US':['CGI product imagery','we create the model','interior setting','furniture visualization','surface digitization'],
'fr':['rendus CGI photoréalistes','nous créons le modèle','intérieur','visualisation de mobilier','numérisation des surfaces'],
'it':['rendering CGI fotorealistici','realizziamo il modello','ambiente','visualizzazione di mobili','digitalizzazione delle superfici']}
extra={
'de':[' Unsere {a} bildet die Grundlage für Produktbilder und Varianten.','Die {a} schafft dafür die Materialgrundlage. '],
'en-US':[' Our {a} provides the foundation for product images and variants.','Our {a} provides the material foundation. '],
'fr':[' Notre {a} fournit la base des images produits et des variantes.','La {a} fournit la base des matières. '],
'it':[' La nostra {a} fornisce la base per le immagini prodotto e le varianti.','La {a} fornisce la base dei materiali. ']}
paths=['/3d-visualisierung/produkt','/3d-visualisierung/3d-modellieren','/3d-visualisierung/interior-raum-visualisierung','/3d-visualisierung/moebel','/3d-visualisierung/oberflaechen-digitalisieren']
rich={}
original=json.loads((r/'content/landing-before-seo.json').read_text())
for l,d in D.items():
 a=anchors[l];link=lambda i:'<a href="'+paths[i]+'">'+a[i]+'</a>'
 material=original[l]['competencies'][0][1];first,rest=material.split('. ',1)
 material=first+'. '+extra[l][1].format(a=a[4])+rest
 competence=original[l]['competenceText']+extra[l][0].format(a=a[3])
 rich[l]={
 'intro':d['introText'].replace(a[0],link(0)),
 'step1':d['steps'][0][1].replace(a[1],link(1)),
 'editorial':d['editorialCopy'].replace(a[2],link(2),1),
 'competence':competence.replace(a[3],link(3)),
 'material':material.replace(a[4],link(4))}
 d['competenceText']=competence;d['competencies'][0][1]=material
 d['heroAlt']={'de':'Drahtgittermodell eines Stuhls mit geflochtener Sitzfläche aus der CGI-Möbelproduktion von Danthree Studio','en-US':'Wireframe model of a chair with a woven seat from Danthree Studio’s CGI furniture production','fr':'Modèle filaire d’une chaise à assise tressée, issu de la production CGI de mobilier de Danthree Studio','it':'Modello wireframe di una sedia con seduta intrecciata dalla produzione CGI di mobili di Danthree Studio'}[l]
p.write_text(json.dumps(D,ensure_ascii=False,indent=2));(r/'content/rich-text.json').write_text(json.dumps(rich,ensure_ascii=False,indent=2))
(r/'qa/content.html').write_text('<meta charset="utf-8"><pre id="copy">'+html.escape(json.dumps(D,ensure_ascii=False))+'</pre>')
p=r/'content/editorial.html';s=p.read_text().replace('einem festen Interior','einem festen <a href="/3d-visualisierung/interior-raum-visualisierung">Interior</a>');p.write_text(s)
p=r/'content/inline-embed.html';s=p.read_text().replace('viewer-bfe1e53480a5.html','viewer-618038b1863a.html');p.write_text(s)
(r/'qa/embeds.html').write_text('<meta charset="utf-8">'+''.join('<pre id="'+k+'">'+html.escape((r/f'content/{k}.html').read_text())+'</pre>' for k in ['inline-embed','editorial','closing','hero']))

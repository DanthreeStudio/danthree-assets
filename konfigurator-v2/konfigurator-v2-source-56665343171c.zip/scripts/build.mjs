import fs from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
const root=new URL('..',import.meta.url);const read=p=>fs.readFileSync(new URL(p,root),'utf8');
const strip=s=>s.replace(/^export /gm,'');
const font=fs.readFileSync(new URL('assets/FuturaPTBook.otf',root)).toString('base64');
const style=read('src/style.css').replace('../assets/FuturaPTBook.otf',`data:font/otf;base64,${font}`);
let app=read('src/app.mjs').replace(/^import .*\n/gm,'');
app=app.replace(/let manifest=await fetch\([^\n]+;/,'let manifest='+JSON.stringify(JSON.parse(read('content/assets.json')))+';');
app=app.replace("fixtureURL=(await import('./fixture.mjs')).fixtureURL",'fixtureURL=diagnosticFixtureURL');
const js=[strip(read('src/core.mjs')),strip(read('src/i18n.mjs')),strip(read('src/metrics.mjs')),strip(read('src/fixture.mjs')).replace('function fixtureURL','function diagnosticFixtureURL'),app].join('\n');
const html=read('index.html').replace('<link rel="stylesheet" href="src/style.css">','<style>'+style+'</style>').replace('<script type="module" src="src/app.mjs"></script>','<script type="module">'+js.replace(/<\/script/gi,'<\\/script')+'</script>');
fs.mkdirSync(new URL('dist/',root),{recursive:true});fs.writeFileSync(new URL('dist/index.html',root),html);console.log('Public static bundle bytes:',Buffer.byteLength(html));

const name='viewer-'+createHash('sha256').update(html).digest('hex').slice(0,12)+'.html';
fs.writeFileSync(new URL('dist/'+name,root),html);
fs.writeFileSync(new URL('dist/release.json',root),JSON.stringify({file:name,bytes:Buffer.byteLength(html)},null,2));
console.log('Versioned public file:',name);

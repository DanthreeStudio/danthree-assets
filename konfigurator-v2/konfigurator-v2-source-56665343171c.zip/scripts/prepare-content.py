from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[1]
source=root.parent/'arbeitsdokumente/2026-09-19-konfigurator-v2/04-MARKTFASSUNGEN-ENTWURF.md'
text=source.read_text(); extra=json.loads((root/'content/extension.json').read_text()); result={}
for lang,heading in [('de','DE'),('en-US','EN-US'),('fr','FR'),('it','IT')]:
 block=text.split('## '+heading+' ·')[1].split('\n## ')[0]
 fields={}; sections={}; texts=[]
 for line in block.splitlines():
  if ': ' in line:
   k,v=line.split(': ',1)
   if k.startswith('H2 '): sections[k[3:]]=v
   elif k=='Text': texts.append(v)
   else: fields[k]=v
 result[lang]={**fields,'sections':sections,'introText':texts[0],'competenceText':texts[1],'contactText':texts[2],**extra[lang]}
result['de']['Description']='Stoffe und Gestellfarben fotorealistisch erleben: ein bildbasierter 3D Produktkonfigurator für Möbelmarken mit 360°-Ansicht, Details und Interior-Szene.'
(root/'content/landing.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
# A local review surface makes the exact prepared copy available in the browser.
(root/'qa/content.html').write_text('<!doctype html><html lang="de"><meta charset="utf-8"><title>Geprüfte Textdaten V2</title><pre id="copy"></pre><script>fetch("../content/landing.json").then(r=>r.json()).then(d=>document.getElementById("copy").textContent=JSON.stringify(d))</script></html>')

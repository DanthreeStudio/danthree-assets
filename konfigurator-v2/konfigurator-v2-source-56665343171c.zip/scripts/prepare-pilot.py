"""Prepare real 000–047 images; never invent missing renders or approve them."""
import argparse, hashlib, io, json
from pathlib import Path
from PIL import Image, ImageCms, ImageOps

p = argparse.ArgumentParser()
p.add_argument('source', type=Path)
p.add_argument('destination', type=Path)
p.add_argument('--fabric', choices=['f01', 'f02', 'f03'], default='f01')
p.add_argument('--frame', choices=['g01', 'g02'], default='g01')
a = p.parse_args()
files = [x for x in a.source.iterdir() if x.suffix.lower() in ['.png', '.jpg', '.jpeg', '.webp', '.avif']]
by_name = {x.stem: x for x in files}
assert len(files) == 48 and len(by_name) == 48 and set(by_name) == {f'{i:03}' for i in range(48)}, 'Exactly 000–047 required'
assert not a.destination.exists(), 'Use a new output folder to preserve earlier batches'
hashes = set()
dimensions = set()
for x in files:
    digest = hashlib.sha256(x.read_bytes()).hexdigest()
    assert digest not in hashes, 'Duplicate frame content'
    hashes.add(digest)
    with Image.open(x) as im:
        im.load()
        dimensions.add(im.size)
assert len(dimensions) == 1, 'All frames must share dimensions'
assets, report = {}, []
root = f'chair-01/{a.fabric}/{a.frame}/spin'
for i in range(48):
    source = by_name[f'{i:03}']
    with Image.open(source) as original:
        im = ImageOps.exif_transpose(original).convert('RGBA' if 'A' in original.getbands() or 'transparency' in original.info else 'RGB')
        if original.info.get('icc_profile'):
            im = ImageCms.profileToProfile(im, ImageCms.ImageCmsProfile(io.BytesIO(original.info['icc_profile'])), ImageCms.createProfile('sRGB'), outputMode=im.mode)
        entry = {'approved': False}
        for kind, width, key in [('mobile', 768, 'mobileURL'), ('desktop', 1280, 'url'), ('zoom', 2048, 'zoomURL')]:
            version = im.copy()
            version.thumbnail((width, width), Image.Resampling.LANCZOS)
            relative = f'{root}/{kind}/{i:03}.webp'
            target = a.destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            version.save(target, 'WEBP', quality=85, method=6)
            entry[key] = './' + relative
            report.append({'frame': i, 'kind': kind, 'width': version.width, 'height': version.height, 'bytes': target.stat().st_size, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
        assets[f'{root}/{i:03}.png'] = entry
(a.destination / 'assets-fragment.json').write_text(json.dumps(assets, indent=2))
totals = {kind: sum(x['bytes'] for x in report if x['kind'] == kind) for kind in ['mobile', 'desktop', 'zoom']}
initial = sum(x['bytes'] for x in report if x['kind'] == 'mobile' and x['frame'] in [(6 + n * 4) % 48 for n in range(12)])
(a.destination / 'image-bytes.json').write_text(json.dumps({'totals': totals, 'mobileInitial12EncodedBytes': initial, 'frames': report, 'note': 'Encoded file sizes only. Measure actual HTTP transfer in the viewer pilot report. Visual, color and mobile acceptance remain pending.'}, indent=2))
print(json.dumps({'totals': totals, 'mobileInitial12EncodedBytes': initial}))

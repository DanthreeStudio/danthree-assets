import csv,json,html,re,runpy
from pathlib import Path
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'content/landing.json').read_text())
rich=json.loads((root/'content/rich-text.json').read_text())
def flatten(v,p=''):
 if isinstance(v,dict):
  for k,x in v.items():yield from flatten(x,p+'/'+k)
 elif isinstance(v,list):
  for k,x in enumerate(v):yield from flatten(x,p+'/'+str(k))
 else:yield p,v
sources=dict(flatten(data['de']));rows=[]
oldpath=root/'content/weglot-initial-import.csv'
if not oldpath.exists():oldpath.write_bytes((root/'content/weglot-konfigurator.csv').read_bytes())
with oldpath.open() as f: prior={(row['language_to'],row['word_from']):row['word_to'] for row in csv.DictReader(f,delimiter=';')}
for lang in ['en-US','fr','it']:
 target=dict(flatten(data[lang]));pairs={}
 for key,source in sources.items():
  if key in ['/Vorteile','/Schritte','/testimonials'] or source=='Art Direction':continue
  pairs[source]=target[key]
 for a,b in zip(data['de']['benefits'],data[lang]['benefits']):pairs[a[0]+'. '+a[1]]=b[0]+'. '+b[1]
 for key,source in rich['de'].items():
  dest=rich[lang][key];pairs[source]=dest
  srcparts=re.split(r'<a[^>]*>|</a>',source);dstparts=re.split(r'<a[^>]*>|</a>',dest)
  if len(srcparts)!=len(dstparts):raise ValueError(key)
  for a,b in zip(srcparts,dstparts):
   if a.strip() and a.strip() not in ['Interior','Möbelvisualisierung'] and len(a.strip())>2:pairs[a.strip()]=b.strip()
 for a,b in pairs.items():rows.append(['','de','en' if lang=='en-US' else lang,a,b,'Text'])
header=['id','language_from','language_to','word_from','word_to','type']
for filename,chosen in [('weglot-konfigurator.csv',rows),('weglot-seo-delta.csv',[r for r in rows if prior.get((r[2],r[3]))!=r[4]])]:
 with (root/'content'/filename).open('w',newline='') as f:w=csv.writer(f,delimiter=';');w.writerow(header);w.writerows(chosen)
 print(filename,len(chosen))
runpy.run_path(str(root/'scripts/prepare-schema.py'))

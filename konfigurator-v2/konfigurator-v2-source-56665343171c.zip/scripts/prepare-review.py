"""Local line-wrap review of exported Webflow blocks; not a Weglot live test."""
from pathlib import Path
from lxml import html, etree
import csv, json, re, zipfile, copy

root = Path(__file__).resolve().parents[1]
source = root / 'qa/webflow-final/3d-visualisierung/3d-konfigurator.html'
data = json.loads((root / 'content/landing.json').read_text())
rich = json.loads((root / 'content/rich-text.json').read_text())
copy_delta = json.loads((root / 'qa/home-living-copy-final.json').read_text())
release = json.loads((root / 'dist/release.json').read_text())
rows = list(csv.DictReader((root / 'content/weglot-konfigurator.csv').open(), delimiter=';'))
review = root / 'qa/review'
review.mkdir(exist_ok=True)
norm = lambda s: ' '.join(s.split())
for lang in data:
    doc = html.fromstring(source.read_text())
    # Apply the current page-specific copy to the unchanged exported layout.
    doc.xpath('//h1')[0].text = copy_delta['de']['H1']
    doc.xpath('//div[contains(@class,"hero-subheading home-hero-new")]')[0].text = copy_delta['de']['Hero']
    for n in doc.xpath('//h2|//p'):
        text = norm(n.text_content())
        if text == 'Derselbe Sessel. Eine andere Raumwirkung.':
            n.text = copy_delta['de']['editorialTitle']
        elif text.startswith('Der Startumfang dieses Arbeitsbeispiels umfasst drei Stoffe'):
            n.text = copy_delta['de']['answer']
        elif text.startswith('Ein Stoff verändert mehr als die Farbe eines Sessels.'):
            fragment = html.fromstring('<div>'+copy_delta['de']['introHTML']+'</div>')
            for child in list(n): n.remove(child)
            n.text = fragment.text
            for child in list(fragment): n.append(copy.deepcopy(child))
    doc.set('lang', lang)
    for n in doc.xpath('//script|//noscript'):
        n.getparent().remove(n)
    for n in doc.xpath('//iframe[not(@id="dt-configurator")]'):
        n.getparent().remove(n)
    for n in doc.xpath('//form'):
        n.set('onsubmit', 'return false')
        for button in n.xpath('.//input[@type="submit"]|.//button'):
            button.set('disabled', 'disabled')
    for n in doc.xpath('//*[@src or @href or @srcset]'):
        for attr in ['src', 'href', 'srcset']:
            if n.get(attr):
                n.set(attr, n.get(attr).replace('../css/', '../webflow-final/css/').replace('../images/', '../webflow-final/images/'))
    for n in doc.xpath('//a[contains(@class,"button") and @href="#Portfolio"]'):
        n.set('class', 'button new-cta-button w-button')
    frame = doc.get_element_by_id('dt-configurator')
    frame.set('src', f'/dist/{release["file"]}?embed=1&lang={lang}&parentOrigin=http%3A%2F%2F127.0.0.1%3A4173')
    for n in doc.xpath('//p[contains(@class,"dt-proof-note")]'):
        n.text = data['de']['proofNote']
    language = 'en' if lang == 'en-US' else lang
    mapping = {norm(r['word_from']): r['word_to'] for r in rows if r['language_to'] == language and '<a ' not in r['word_from']}
    if lang != 'de':
        # Linked paragraphs use the same translated text and anchor positions as the content file.
        for key, value in rich['de'].items():
            plain = norm(html.fromstring('<div>'+value+'</div>').text_content())
            for n in doc.xpath('//p'):
                if norm(n.text_content()) == plain:
                    fragment = html.fromstring('<div>'+rich[lang][key]+'</div>')
                    for child in list(n):n.remove(child)
                    n.text = fragment.text
                    for child in list(fragment):n.append(copy.deepcopy(child))
        for n in doc.iter():
            if not isinstance(n.tag, str):continue
            for attr in ['text', 'tail']:
                value = getattr(n, attr)
                if value and norm(value) in mapping:
                    setattr(n, attr, (' ' if value[:1].isspace() else '')+mapping[norm(value)]+(' ' if value[-1:].isspace() else ''))
            for attr in ['alt', 'placeholder', 'content']:
                if n.get(attr) and norm(n.get(attr)) in mapping:n.set(attr,mapping[norm(n.get(attr))])
    robots = etree.SubElement(doc.find('head'),'meta',name='robots',content='noindex,nofollow')
    script = etree.SubElement(doc.find('body'),'script')
    script.text = "window.addEventListener('message',e=>{const f=document.getElementById('dt-configurator');if(e.origin==='http://127.0.0.1:4173'&&e.source===f.contentWindow&&e.data?.type==='danthree:height')f.style.height=Math.max(400,Math.min(2200,e.data.height))+'px'});"
    (review / f'{lang}.html').write_text('<!doctype html>'+html.tostring(doc,encoding='unicode'))
archive = zipfile.ZipFile(root.parent/'arbeitsdokumente/2026-09-19-konfigurator-umsetzung/backup/danthree-final-after-design-seo.webflow.zip')
used = set()
for n in doc.xpath('//*[@src or @srcset]'):
    for attr in ['src','srcset']:
        for value in (n.get(attr) or '').split(','):
            url = value.strip().split(' ')[0]
            if '../webflow-final/images/' in url:used.add('images/'+url.split('/images/')[1])
for name in used:
    if name in archive.namelist():archive.extract(name,root/'qa/webflow-final')
print('Four review pages; local assets:',len(used))

# Danthree Studio — image-based furniture configurator V2

Pilot implementation: 3 fabrics × 2 frame finishes × 48 rotation frames, plus material, junction and interior images (305 approved production images in total).

The renderer assets are not included. Material names, product dimensions and image/model approvals must be supplied before release. The diagnostic dial is explicitly a technical fixture, never a product rendering.

- `src/`: four-language viewer, progressive mobile loading, touch rotation, zoom, bounded image cache and transfer measurement.
- `content/assets.json`: production asset manifest and release gates.
- `scripts/build.mjs`: produces a self-contained, versioned HTML viewer in `dist/`.
- `tests/core.test.mjs`: image count, variant state, asynchronous race and cache checks.
- `content/inline-embed.html`: page embed with origin-checked configuration handoff to the existing Webflow contact form.

Run `node --test tests/core.test.mjs`, then `node scripts/build.mjs`. For local development, run `node scripts/serve.mjs` from this directory.

The existing tracking script and separate 3D viewer are outside this project and remain unchanged.

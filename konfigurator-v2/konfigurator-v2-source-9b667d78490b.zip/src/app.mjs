import {VisitMetrics} from './metrics.mjs';
import {copy} from './i18n.mjs';
import {COUNT,wrap,angle,keyOf,assetPath,changeState,orderAround,LatestRequest,ImageCache,validatePilotNames,sourceURL,preloadIndices} from './core.mjs';
const $=id=>document.getElementById(id), params=new URLSearchParams(location.search);
let lang=copy[params.get('lang')]?params.get('lang'):'de', t=copy[lang];
let state={fabric:'f01',frame:'g01',view:'spin',detail:'fabric',index:6,zoom:1};
const visit=new VisitMetrics(), mobile=matchMedia('(max-width:850px)').matches, saveData=navigator.connection?.saveData===true;
const allowedParents=new Set(['https://www.danthree.studio','https://danthree.studio','https://danthree-final.webflow.io','https://danthree-final.design.webflow.com','https://danthree-final.canvas.webflow.com','http://127.0.0.1:4173']);
let interacted=false;
let displayed=null, pilot=new Map(), pilotURLs=[], fixture=false, fixtureURL, direction=1, preloading='', sourceEpoch=0, importEpoch=0;
let pan={x:0,y:0}, drag=null, raf=0, requestedAt=0, currentError=false;
const latest=new LatestRequest();
const stats={version:2,source:'missing',startedAt:new Date().toISOString(),renderImages:0,commits:0,failures:0,latencyMs:[],preloaded:0,visualApproval:false,deviceApproval:false};
const cache=new ImageCache(url=>new Promise((resolve,reject)=>{const img=new Image();img.decoding='async';const timeout=setTimeout(()=>{img.src='';reject(Error('Image timeout'));},15000);img.onload=async()=>{try{await img.decode();clearTimeout(timeout);resolve(img);}catch(e){clearTimeout(timeout);reject(e);}};img.onerror=()=>{clearTimeout(timeout);reject(Error('Image unavailable'));};img.src=url;}));
let manifest=await fetch('./content/assets.json').then(r=>{if(!r.ok)throw Error('Manifest');return r.json();}).catch(()=>({assets:{},materials:{},models:{},release:false}));
if(params.get('embed')==='1')document.body.classList.add('embedded');
const label=(kind,id)=>manifest.materials?.[kind]?.[id]?.names?.[lang]||id.toUpperCase();
function message(text,error=false){$('status').textContent=text;$('status').parentElement.dataset.error=String(error);currentError=error;}
function available(s){return fixture || (s.view==='spin'&&pilot.has(`${s.fabric}/${s.frame}`)) || manifest.assets?.[assetPath(s)]?.approved===true;}
function urlFor(s,high=false){if(fixture)return fixtureURL(s);const files=pilot.get(`${s.fabric}/${s.frame}`);if(s.view==='spin'&&files)return files[wrap(s.index)];const asset=manifest.assets?.[assetPath(s)];if(!asset?.approved)return null;return sourceURL(asset,{mobile,high});}
function nameFor(s){return `${label('fabric',s.fabric)} / ${label('frame',s.frame)}`;}
function shownText(s){const view=t.views[['spin','details','interior'].indexOf(s.view)];return `${nameFor(s)} · ${view}${s.view==='spin'?` · ${angle(s.index)}°`:s.view==='details'?` · ${t.details[['fabric','frame','junction'].indexOf(s.detail)]}`:''}`;}
function setControls(){
 $('selection').textContent=nameFor(state);
 document.querySelectorAll('[data-view]').forEach(el=>{const selected=el.dataset.view===state.view;el.setAttribute('aria-selected',selected);el.tabIndex=selected?0:-1;});
 $('stage-panel').setAttribute('aria-labelledby',`tab-${state.view}`);$('details').hidden=state.view!=='details';
 document.querySelectorAll('[data-detail]').forEach(el=>el.setAttribute('aria-pressed',el.dataset.detail===state.detail));
 document.querySelectorAll('input[name=fabric],input[name=frame]').forEach(el=>el.checked=state[el.name]===el.value);
 for(const id of ['left','right'])$(id).disabled=state.view!=='spin'||!available(state);
 $('in').disabled=!displayed||currentError;$('out').disabled=!displayed||state.zoom<=1;$('reset').disabled=!displayed;
 $('angle').value=displayed?.view==='spin'?`${angle(displayed.index).toLocaleString(lang,{minimumFractionDigits:1})}°`:'—';
 $('zoom').value=`${Math.round(state.zoom*100)}%`;
 $('fixture-label').hidden=!fixture;
 updateModels();
}
function transform(){
 const img=$('product'),stage=$('stage'), rect=stage.getBoundingClientRect();
 const size=img.naturalWidth?Math.min(rect.width/img.naturalWidth,rect.height/img.naturalHeight):1;
 const max=img.naturalWidth?Math.max(1,Math.min(4,1/(size*devicePixelRatio))):1;
 state.zoom=Math.min(state.zoom,max);
 const limitX=Math.max(0,(img.naturalWidth*size*state.zoom-rect.width)/2),limitY=Math.max(0,(img.naturalHeight*size*state.zoom-rect.height)/2);
 pan.x=Math.max(-limitX,Math.min(limitX,pan.x));pan.y=Math.max(-limitY,Math.min(limitY,pan.y));
 img.style.transform=`translate(${pan.x}px,${pan.y}px) scale(${state.zoom})`;$('zoom').value=`${Math.round(state.zoom*100)}%`;
 $('in').disabled=!displayed||currentError||state.zoom>=max-0.01;$('out').disabled=!displayed||state.zoom<=1;
}
async function show(){
 const snapshot={...state},url=urlFor(snapshot,snapshot.zoom>1);requestedAt=performance.now();const started=requestedAt;
 if(!url){latest.invalidate();$('stage').setAttribute('aria-busy','false');$('retry').hidden=true;message(t.missing+(displayed?` ${t.ready}: ${shownText(displayed)}.`:''),true);setControls();return;}
 $('stage').setAttribute('aria-busy','true');$('retry').hidden=true;message(t.loading);setControls();
 await latest.run(()=>cache.get(url),img=>{
   const product=$('product');product.src=img.src;product.alt=`${t.alt} · ${shownText(snapshot)}${fixture?' · '+t.fixtureBadge:''}`;product.hidden=false;$('empty').hidden=true;
   displayed=snapshot;visit.firstImage();$('stage').setAttribute('aria-busy','false');stats.commits++;stats.latencyMs.push(Math.round((performance.now()-started)*10)/10);if(stats.latencyMs.length>500)stats.latencyMs.shift();
   message(`${t.ready}: ${shownText(snapshot)}`);setControls();transform();renderMetrics();preload();
 },()=>{stats.failures++;$('stage').setAttribute('aria-busy','false');$('retry').hidden=false;message(t.failed,true);setControls();renderMetrics();});
}
async function preload(){
 if(state.view!=='spin')return;
 const token=`${sourceEpoch}/${state.fabric}/${state.frame}/${interacted}`;if(preloading===token)return;
 preloading=token;stats.preloaded=0;const base={...state};const queue=preloadIndices(state.index,{mobile,interacted,saveData});let cursor=0;
 await Promise.all(Array.from({length:3},async()=>{
  while(cursor<queue.length&&preloading===token){const index=queue[cursor++],u=urlFor({...base,index},false);if(!u)continue;try{await cache.get(u);if(preloading===token)stats.preloaded++;}catch{} }
 }));if(preloading===token)renderMetrics();
}
function change(patch){interacted=true;state=changeState(state,patch);if(patch.fabric||patch.frame){preloading='';}show();}
function zoom(delta){state=changeState(state,{zoom:state.zoom+delta});if(delta<0)pan={x:0,y:0};show();}
function renderMetrics(){const times=[...stats.latencyMs].sort((a,b)=>a-b);$('metrics').textContent=JSON.stringify({source:stats.source,images:stats.renderImages,preloaded:stats.preloaded,decodedMiB:Math.round(cache.bytes/1024/1024),committedFrames:stats.commits,failedRequests:stats.failures,p95DisplayLatencyMs:times[Math.floor(times.length*.95)]??null,visualApproval:false,mobile,visit:visit.snapshot()},null,2);}
function updateModels(){
 const model=manifest.models?.[`${state.fabric}/${state.frame}`],box=$('model-actions');box.replaceChildren();box.hidden=true;
 if(!model?.approved||!model?.dimensionsCm||!model?.licenseURL||!model?.glbURL)return;
 if(model.downloadTested){const a=document.createElement('a');a.href=model.glbURL;a.textContent='3D · GLB';a.setAttribute('download','');box.append(a);box.hidden=false;}
 // AR activation additionally needs matching variant, scale, real-device review and reviewed HTTPS target.
 if(model.arDeviceTested&&model.arPageURL){const a=document.createElement('a');a.href=model.arPageURL;a.textContent='AR ↗';a.rel='noopener';box.append(a);box.hidden=false;}
}
function populate(kind,ids){const holder=$(kind==='fabric'?'fabrics':'frames');holder.replaceChildren();for(const id of ids){const l=document.createElement('label');l.className='choice';const r=document.createElement('input');r.type='radio';r.name=kind;r.value=id;r.checked=state[kind]===id;r.setAttribute('aria-label',label(kind,id));r.onchange=()=>change({[kind]:id});const sw=document.createElement('span');sw.className='swatch';sw.setAttribute('aria-hidden','true');const material=manifest.materials?.[kind]?.[id];if(material?.approved&&material.swatchURL){const img=document.createElement('img');img.src=material.swatchURL;img.alt='';sw.replaceWith(img);l.append(r,img);}else l.append(r,sw);const text=document.createElement('span');text.textContent=label(kind,id);l.append(text);holder.append(l);}}
function translate(){t=copy[lang];const a11y={de:['Sprache','Konfigurator','Ansicht','Angezeigter Winkel','Auswahl für deine Anfrage'],'en-US':['Language','Configurator','View','Displayed angle','Selection for your inquiry'],fr:['Langue','Configurateur','Vue','Angle affiché','Sélection pour ta demande'],it:['Lingua','Configuratore','Vista','Angolo visualizzato','Selezione per la tua richiesta']}[lang];$('language').setAttribute('aria-label',a11y[0]);document.querySelector('.configurator').setAttribute('aria-label',a11y[1]);document.querySelector('.tabs').setAttribute('aria-label',a11y[2]);$('angle').setAttribute('aria-label',a11y[3]);$('inquiry-copy').setAttribute('aria-label',a11y[4]);document.documentElement.lang=lang;$('language').value=lang;const mapping={'work-label':'work',eyebrow:'eyebrow',title:'title',intro:'intro','empty-title':'emptyTitle','empty-copy':'emptyCopy','example-label':'example','product-title':'product','material-note':'materialNote','selection-label':'selection',inquiry:'inquiry','model-note':'modelNote',reset:'reset',hint:'hint','pilot-title':'pilotTitle','pilot-copy':'pilotCopy','pilot-combo-label':'pilotCombo',fixture:'fixture','fixture-label':'fixtureBadge',report:'report','contact-title':'contactTitle','contact-copy':'contactCopy','contact-link':'contactLink','footer-label':'footer',retry:'retry'};for(const [id,key] of Object.entries(mapping))$(id).textContent=t[key];$('title').style.whiteSpace='pre-line';$('fabric-label').textContent=`01 / ${t.fabric}`;$('frame-label').textContent=`02 / ${t.frame}`;document.querySelectorAll('[data-view]').forEach((e,i)=>e.textContent=t.views[i]);document.querySelectorAll('[data-detail]').forEach((e,i)=>e.textContent=t.details[i]);for(const [id,key]of Object.entries({left:'left',right:'right',in:'zoomIn',out:'zoomOut',stage:'stage'}))$(id).setAttribute('aria-label',t[key]);populate('fabric',['f01','f02','f03']);populate('frame',['g01','g02']);show();}
$('language').onchange=e=>{lang=e.target.value;translate();};
document.querySelectorAll('[data-view]').forEach(el=>{el.onclick=()=>change({view:el.dataset.view});el.onkeydown=e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const tabs=[...document.querySelectorAll('[data-view]')],i=tabs.indexOf(el),next=e.key==='Home'?0:e.key==='End'?2:(i+(e.key==='ArrowRight'?1:2))%3;tabs[next].focus();change({view:tabs[next].dataset.view});};});
document.querySelectorAll('[data-detail]').forEach(el=>el.onclick=()=>change({detail:el.dataset.detail}));
$('left').onclick=()=>{direction=-1;change({index:state.index-1});};$('right').onclick=()=>{direction=1;change({index:state.index+1});};$('in').onclick=()=>zoom(.25);$('out').onclick=()=>zoom(-.25);$('reset').onclick=()=>{pan={x:0,y:0};change({index:6,zoom:1});};$('retry').onclick=show;
$('stage').onkeydown=e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)&&state.view==='spin'&&available(state)){e.preventDefault();direction=e.key==='ArrowLeft'?-1:1;change({index:state.index+direction});}else if(['+','=','-'].includes(e.key)&&displayed){e.preventDefault();zoom(e.key==='-'?-.25:.25);}else if(e.key==='Home'){e.preventDefault();$('reset').click();}};
$('stage').onpointerdown=e=>{if(e.button!==0||!displayed||!available(state))return;interacted=true;preloading='';drag={x:e.clientX,y:e.clientY,index:state.index,pan:{...pan},id:e.pointerId,horizontal:false};};
$('stage').onpointermove=e=>{if(!drag||e.pointerId!==drag.id)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(!drag.horizontal){if(Math.abs(dy)>Math.abs(dx)&&Math.abs(dy)>8){drag=null;return;}if(Math.abs(dx)<8)return;drag.horizontal=true;$('stage').setPointerCapture(e.pointerId);}if(state.zoom>1){pan={x:drag.pan.x+dx,y:drag.pan.y+dy};transform();return;}if(state.view!=='spin')return;const index=wrap(drag.index-Math.round(dx/($('stage').clientWidth/COUNT)));direction=dx<0?1:-1;if(index===state.index)return;state=changeState(state,{index});if(!raf)raf=requestAnimationFrame(()=>{raf=0;show();});};
function endDrag(){drag=null;}for(const type of ['pointerup','pointercancel','lostpointercapture'])$('stage').addEventListener(type,endDrag);
window.addEventListener('resize',transform);
async function useFixture(){fixtureURL=(await import('./fixture.mjs')).fixtureURL;sourceEpoch++;preloading='';latest.invalidate();cache.clear();fixture=true;stats.source='technical-test-pattern';stats.renderImages=0;message(t.fixtureReady);show();}
$('fixture').onclick=useFixture;
$('pilot-files').onchange=async e=>{
 const token=++importEpoch, urls=[],hashes=new Set();message(t.importing);$('pilot-files').disabled=true;
 try {const files=validatePilotNames([...e.target.files]);let size=null;
   for(const f of files){if(f.size>40*1024*1024)throw Error('Use web-size pilot images');const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await f.arrayBuffer()))).map(x=>x.toString(16).padStart(2,'0')).join('');if(hashes.has(digest))throw Error('Duplicate content');hashes.add(digest);const u=URL.createObjectURL(f);urls.push(u);const img=await cache.get(u);const dims=`${img.naturalWidth}x${img.naturalHeight}`;if(size&&size!==dims)throw Error('Dimensions differ');size=dims;}
   if(token!==importEpoch)throw Error('Superseded');const combo=$('pilot-combo').value;const [fabric,frame]=combo.split('/');latest.invalidate();sourceEpoch++;preloading='';for(const u of pilotURLs)URL.revokeObjectURL(u);pilotURLs=urls;pilot.clear();pilot.set(combo,urls);cache.clear();fixture=false;stats.source='local-pilot';stats.renderImages=48;stats.pilot={combination:combo,dimensions:size,bytes:files.reduce((a,f)=>a+f.size,0),uniqueSHA256:hashes.size};state=changeState(state,{fabric,frame,view:'spin',index:6,zoom:1});await show();message(t.imported);
 }catch{for(const u of urls)URL.revokeObjectURL(u);message(t.invalidPilot,true);}finally{$('pilot-files').disabled=false;renderMetrics();}
};
$('inquiry').onclick=()=>{const value=`${t.product}: ${nameFor(state)} · ${t.views[['spin','details','interior'].indexOf(state.view)]} · ${angle(state.index)}°`;const field=$('inquiry-copy');field.hidden=false;field.value=value;$('inquiry-status').textContent=t.inquiryDone;
 // Host bridge only posts to explicitly allowed Danthree origins, never to '*'.
 const parentOrigin=params.get('parentOrigin');if(parent!==window&&allowedParents.has(parentOrigin))parent.postMessage({type:'danthree:configuration',version:2,selection:{fabric:state.fabric,frame:state.frame,index:state.index,view:state.view},text:value},parentOrigin);
 if(!document.body.classList.contains('embedded'))field.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'});
};
$('report').onclick=()=>{const report={...stats,visit:visit.snapshot(),mobile,saveData,language:lang,requested:state,displayed,decodedMiB:cache.bytes/1048576,scope:{fabrics:3,frames:2,spin:48,totalRenders:305},note:'Technical observations only. No automatic visual acceptance or device certification.'};const u=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download='danthree-pilot-report.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);};
window.addEventListener('pagehide',()=>pilotURLs.forEach(u=>URL.revokeObjectURL(u)));
translate();renderMetrics();

// The host can size its inline iframe without truncating mobile content.
const host=params.get('parentOrigin');
if(parent!==window && allowedParents.has(host)) {
  let lastHeight=0;
  new ResizeObserver(()=>{const height=Math.ceil(document.body.getBoundingClientRect().height);if(Math.abs(height-lastHeight)>2){lastHeight=height;parent.postMessage({type:'danthree:height',version:2,height},host);}}).observe(document.body);
}

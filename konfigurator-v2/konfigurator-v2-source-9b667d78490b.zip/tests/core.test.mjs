import test from 'node:test';
import assert from 'node:assert/strict';
import {wrap,angle,assetPath,changeState,LatestRequest,ImageCache,validatePilotNames,sourceURL,preloadIndices} from '../src/core.mjs';
const state={fabric:'f01',frame:'g01',index:47,zoom:2,view:'spin',detail:'fabric'};
test('rotation wraps in both directions and material swaps preserve viewpoint',()=>{
 assert.equal(wrap(-1),47);assert.equal(angle(48),0);
 const next=changeState(state,{fabric:'f03',frame:'g02'});assert.equal(next.index,47);assert.equal(next.zoom,2);
 assert.match(assetPath(next),/f03\/g02\/spin\/047.png$/);
});
test('305 unique production images cover all views and share only independent details',()=>{
 const paths=new Set();for(const fabric of ['f01','f02','f03'])for(const frame of ['g01','g02']){
  for(let index=0;index<48;index++)paths.add(assetPath({...state,fabric,frame,index}));
  paths.add(assetPath({...state,fabric,frame,view:'interior'}));
  for(const detail of ['fabric','frame','junction'])paths.add(assetPath({...state,fabric,frame,view:'details',detail}));
 }assert.equal(paths.size,305);
});
test('an obsolete image or error never overwrites the newest selection',async()=>{
 const latest=new LatestRequest();let resolveOld,rejectOld,result;
 const old=latest.run(()=>new Promise(r=>resolveOld=r),v=>result=v,()=>result='error');
 await latest.run(()=>Promise.resolve('new'),v=>result=v,()=>{});resolveOld('old');await old;assert.equal(result,'new');
 const failed=latest.run(()=>new Promise((_,r)=>rejectOld=r),()=>{},()=>result='error');
 latest.invalidate();rejectOld(Error('old error'));await failed;assert.equal(result,'new');
});
test('image cache deduplicates, respects decoded budget, and rejects stale cache insertion',async()=>{
 let count=0;const c=new ImageCache(async()=>{count++;return{naturalWidth:10,naturalHeight:10}},800);
 await Promise.all([c.get('a'),c.get('a')]);assert.equal(count,1);await c.get('b');await c.get('c');assert.equal(c.bytes,800);assert.equal(c.items.has('a'),false);
 let resolve;const pendingCache=new ImageCache(()=>new Promise(r=>resolve=r));const job=pendingCache.get('old');pendingCache.clear();resolve({naturalWidth:20,naturalHeight:20});await job;assert.equal(pendingCache.bytes,0);
});
test('pilot import requires exactly the complete ordered frame set',()=>{
 const files=Array.from({length:48},(_,i)=>({name:String(i).padStart(3,'0')+'.webp'}));assert.equal(validatePilotNames(files.reverse())[0].name,'000.webp');
 assert.throws(()=>validatePilotNames(files.slice(1)));assert.throws(()=>validatePilotNames([...files.slice(1),files[1]]));
});
test('mobile defers unused frames and unapproved assets cannot be displayed',()=>{
 assert.equal(preloadIndices(47,{mobile:true}).length,12);assert.equal(new Set(preloadIndices(47,{mobile:true})).size,12);assert.equal(preloadIndices(47,{mobile:true,interacted:true}).length,48);
 assert.equal(preloadIndices(0,{saveData:true}).length,1);
 assert.equal(sourceURL({url:'full',mobileURL:'small'}),null);
 assert.equal(sourceURL({approved:true,url:'full',mobileURL:'small'},{mobile:true}),'small');
 assert.equal(sourceURL({approved:true,url:'full',mobileURL:'small',zoomURL:'zoom'},{mobile:true,high:true}),'zoom');
});
